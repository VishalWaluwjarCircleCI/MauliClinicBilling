package com.vishwamauli.billing;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.TextView;
import android.view.Gravity;
public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        String url = BuildConfig.BILLING_URL;
        if (!url.startsWith("https://")) {
            TextView msg=new TextView(this);
            msg.setText("Mauli Billing setup pending. Deploy Google Apps Script and set billingUrl in cloud build.");
            msg.setPadding(40,80,40,40); msg.setGravity(Gravity.CENTER);
            setContentView(msg); return;
        }
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl(url);
    }
    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
